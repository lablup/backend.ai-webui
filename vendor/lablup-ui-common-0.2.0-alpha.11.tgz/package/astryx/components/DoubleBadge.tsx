// The Astryx CLI pairs each component doc with a same-stem source file.
// ui-common ships no source, so this names the export instead.
export { DoubleBadge } from "@lablup/ui-common";
