// The Astryx CLI pairs each component doc with a same-stem source file.
// ui-common ships no source, so this names the export instead.
export { CountdownBorder } from "@lablup/ui-common";
